#!/usr/bin/env bash
/usr/local/bin/icalBuddy -po "title,datetime,attendees,location,notes" -nnr " " -nc -li 3 eventsToday